package com.example.tebakangka

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    //menyimpan angka rahasia secara acak dari 0-100
    private var angkaRahasia = (0..100).random()
    private var skor = 100 //menentukan skor awal
    private var permainanSelesai = false //penanda apakah permainan sudah selesai

    //komponen tampilan sesuai dengan XML(tampilan)
    private lateinit var etTebakan: EditText
    private lateinit var tvSkor: TextView
    private lateinit var tvPesan: TextView
    private lateinit var btnTebak: Button
    private lateinit var btnUlang: Button

    //fungsi ini akan dijalankan ketika Activity pertama kali dibuat
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) //menghubungkan activity dengan XML(tampilan)

        //menghubungkan variabel kotlin dengan komponen XML berdasarkan ID
        etTebakan = findViewById(R.id.etTebakan)
        tvSkor = findViewById(R.id.tvSkor)
        tvPesan = findViewById(R.id.tvPesan)
        btnTebak = findViewById(R.id.btnTebak)
        btnUlang = findViewById(R.id.btnUlang)

        //menjalankan fungsi periksa tebakan jika tombol ditekan
        btnTebak.setOnClickListener {
            periksaTebakan()
        }
        //menjalankan fungsi mulai ulang jika tombol ditekan
        btnUlang.setOnClickListener {
            mulaiUlang()
        }
    }

    //fungsi ini akan memeriksa angka tebakan
    private fun periksaTebakan() {
        //keluar dari pengecekan jika kondisi permainan selesai
        if (permainanSelesai) return

        //mengambil teks input lalu mengubahnya menjadi bilangan bulat
        //jika bukan merupakan bilangan bulat/kosong hasil nya null(tidak akan menyimpan apa apa)
        val tebakan = etTebakan.text.toString().toIntOrNull()

        //melakukan cek apakah user telah memasukkan angka
        if (tebakan == null) {
            etTebakan.error = "Masukkan angka terlebih dahulu"
            return
        }

        //memastikan angka yang dimasukkan dalam rentang 0-100
        if (tebakan !in 0..100) {
            etTebakan.error = "Angka harus antara 0 dan 100"
            return
        }

        if (tebakan == angkaRahasia) { //melakukan pengecekkan jika tebakan benar
            //menuliskan notif dan skor akhir
            tvPesan.text =
                "Benar! Angka rahasianya adalah $angkaRahasia.\n" +
                        "Skor akhir: $skor"

            permainanSelesai = true //set kondisi permainan selesai
            //menonaktifkan tombol tebak dan mengaktifkan tombol main ulang
            btnTebak.isEnabled = false
            btnUlang.visibility = View.VISIBLE

        } else { //jika tebakan salah
            skor = (skor - 10).coerceAtLeast(0) //mengurangi skor
            tvSkor.text = "Skor: $skor" //update skor

            //memberi petunjuk angka lebih atau kurang dari angka tebakan
            val petunjuk = if (tebakan < angkaRahasia) {
                "Angka rahasia lebih besar!"
            } else {
                "Angka rahasia lebih kecil!"
            }

            if (skor == 0) { //jika skor telah habis
                //memberi informasi skor dan jawaban
                tvPesan.text =
                    "$petunjuk\nSkor habis! Angka rahasianya $angkaRahasia."

                permainanSelesai = true //set kondisi permainan selesai
                //menonaktifkan tombol tebak dan mengaktifkan tombol main ulang
                btnTebak.isEnabled = false
                btnUlang.visibility = View.VISIBLE
            } else { //jika belum habis kan memberi informasi pengurangan poin
                tvPesan.text =
                    "$petunjuk\nSkor berkurang 10 poin."
            }
        }

        etTebakan.text.clear() //mengosongkan kolom input
    }

    //fungsi untuk mengulang game
    private fun mulaiUlang() {
        angkaRahasia = (0..100).random() //membuat angka acak lagi
        skor = 100 //set skor awal
        permainanSelesai = false //mengubah status permainan menjadi belum selesai

        //update tampilan skor dan pesan
        tvSkor.text = "Skor: 100"
        tvPesan.text = "Silakan masukkan tebakanmu!"
        etTebakan.text.clear() //mengosongkan kolom input

        btnTebak.isEnabled = true //mengaktifkan tombol tebak
        btnUlang.visibility = View.GONE //menyembunyikan tombol main ulang
    }
}